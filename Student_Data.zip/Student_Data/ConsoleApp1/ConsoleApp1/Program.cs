﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;


namespace ConsoleApp1
{
    class Program
    {
       
        ArrayList list = new ArrayList();
        object[] arr;
        DataTable dt = new DataTable();
        public int row_c = 1;
        public double largest = 0, smallest = 0;
        public string largest_name = "", smallest_name = "";
        public int less = 0, high = 0;


        public void gettable(int arr_value)
        {
            dt=table();
            arr= new object[arr_value];
        }

        public void  abc( int i)
        {
            try
            {
                largest = 0;
                smallest = 0;
                largest_name = "";
                smallest_name = "";
                double rate1 = 10, rate2 = 7.5, rate3 = 5;
                less = 0;
                high = 0;
                for (int k = 1; k < i + 1; k++)
                {
                    Console.WriteLine("Please enter information for customer " + k);
                    Console.Write("Customer Name :  ");
                    arr[0] = Console.ReadLine();
                a:

                    Console.Write("Number of months for membership (1 - 120):  ");
                    int mth = Convert.ToInt32(Console.ReadLine());
                    if (mth <= 120)
                    {
                        arr[1] = mth;
                    r:
                        Console.Write("Receive Special offer? (Y or N):  ");
                        string yndn = "";

                        yndn = Console.ReadLine();

                        if (yndn.Equals("Y") || yndn.Equals("y"))
                        {
                            arr[2] = yndn;
                            if (mth < 12)
                            {
                                less++;
                                double dis = (mth * rate1) * 0.1;
                                arr[3] = (mth * rate1) - dis;
                            }
                            else if (mth >= 12 && mth <= 24)
                            {
                                high++;
                                double dis = (mth * rate1) * 0.1;
                                arr[3] = (mth * rate2) - dis;
                            }
                            else if (mth > 24)
                            {
                                high++;
                                double dis = (mth * rate3) * 0.1;
                                arr[3] = (mth * rate3) - dis;
                            }

                            Console.WriteLine("The membership fee for " + arr[0] + " is " + arr[3]);
                        }
                        else if (yndn.Equals("N") || yndn.Equals("n"))
                        {
                            arr[2] = yndn;
                            if (mth < 12)
                            {
                                less++;
                                arr[3] = (mth * rate1);
                            }
                            else if (mth >= 12 && mth <= 24)
                            {
                                high++;
                                arr[3] = (mth * rate2);
                            }
                            else if (mth > 24)
                            {
                                high++;
                                arr[3] = (mth * rate3);
                            }

                            Console.WriteLine("The membership fee for " + arr[3] + " is ");
                        }
                        else
                        {
                            goto r;
                        }

                    }
                    else
                    {
                        Console.WriteLine("\nPlease enter value range between 1 to 120 :  ");
                        goto a;
                    }
                    Console.WriteLine();
                    dt.Rows.Add(arr);
                }

                largest = Convert.ToDouble(dt.Rows[0]["Fees"].ToString());
                smallest = Convert.ToDouble(dt.Rows[0]["Fees"].ToString());

                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    if (Convert.ToDouble(dt.Rows[j]["Fees"].ToString()) > largest)
                    {
                        largest = Convert.ToDouble(dt.Rows[j]["Fees"].ToString());
                        largest_name = dt.Rows[j]["Name"].ToString();
                    }

                    if (Convert.ToDouble(dt.Rows[j]["Fees"].ToString()) < smallest)
                    {
                        smallest = Convert.ToDouble(dt.Rows[j]["Fees"].ToString());
                        smallest_name = dt.Rows[j]["Name"].ToString();
                    }
                }
                console_repersent();
               // Console.Write("\n\nNew entry press 1 other wise 2 :");
               // int re = Convert.ToInt32(Console.ReadLine());
               // return 1;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                
            }
        }

        public DataTable table()
        {
                DataTable table = new DataTable();
                table.Columns.Add("Name", typeof(string));
                table.Columns.Add("Month", typeof(string));
                table.Columns.Add("Offer", typeof(string));
                table.Columns.Add("Fees", typeof(string));                
                return table;
        }
            
        public void console_repersent()
        {
            try
            {
                row_c = 1;
                int[] maxLengths = new int[dt.Columns.Count];

                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    maxLengths[i] = dt.Columns[i].ColumnName.Length;

                    foreach (DataRow row in dt.Rows)
                    {
                        if (!row.IsNull(i))
                        {
                            int length = row[i].ToString().Length;

                            if (length > maxLengths[i])
                            {
                                maxLengths[i] = length;
                            }
                        }
                    }
                }
               
                   Console.WriteLine("-------------------------------------------------------");
                   Console.WriteLine("          Summery of membership fee ");
                Console.WriteLine("-------------------------------------------------------");

                Console.WriteLine();
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                    Console.Write(dt.Columns[i].ColumnName.PadRight(maxLengths[i] + 2));
                    }

                Console.WriteLine();
                Console.WriteLine("-------------------------------------------------------");
                Console.WriteLine("-------------------------------------------------------");
                    foreach (DataRow row in dt.Rows)
                    {
                        for (int i = 0; i < dt.Columns.Count; i++)
                        {
                            if (!row.IsNull(i))
                            {
                            Console.Write(row[i].ToString().PadRight(maxLengths[i] + 2));
                            }
                            else
                            {
                            Console.Write(new string(' ', maxLengths[i] + 2));
                            }
                        }

                    Console.WriteLine();
                    }
                Console.WriteLine("-------------------------------------------------------");
                Console.WriteLine("The Customer Spending the most is " + largest_name + " : $" + largest);
                Console.WriteLine("The Customer Spending the least is " + smallest_name + " : $" + smallest);
                Console.WriteLine("The Number of member with < 12 Month : " + less);
                Console.WriteLine("The Number of member with >= 12 Month : " + high);
               // Console.Close();
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public void ReadData()
            {
                try
                {
                    row_c = 1;
                    int[] maxLengths = new int[dt.Columns.Count];

                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        maxLengths[i] = dt.Columns[i].ColumnName.Length;

                        foreach (DataRow row in dt.Rows)
                        {
                            if (!row.IsNull(i))
                            {
                                int length = row[i].ToString().Length;

                                if (length > maxLengths[i])
                                {
                                    maxLengths[i] = length;
                                }
                            }
                        }
                    }

                    using (StreamWriter sw = new StreamWriter(@"E:\Excel\Student.txt", false))
                    {
                    sw.WriteLine("-------------------------------------------------------");
                    sw.WriteLine("          Summery of membership fee ");
                    sw.WriteLine("-------------------------------------------------------");                      
                      
                        sw.WriteLine();
                        for (int i = 0; i < dt.Columns.Count; i++)
                        {
                            sw.Write(dt.Columns[i].ColumnName.PadRight(maxLengths[i] + 2));
                        }

                    sw.WriteLine();
                    sw.WriteLine("-------------------------------------------------------");
                    sw.WriteLine("-------------------------------------------------------");
                    foreach (DataRow row in dt.Rows)
                        {
                            for (int i = 0; i < dt.Columns.Count; i++)
                            {
                                if (!row.IsNull(i))
                                {
                                    sw.Write(row[i].ToString().PadRight(maxLengths[i] + 2));
                                }
                                else
                                {
                                    sw.Write(new string(' ', maxLengths[i] + 2));
                                }
                            }

                            sw.WriteLine();
                        }
                    sw.WriteLine("----------------------------------------------------------------");
                    sw.WriteLine("The Customer Spending the most is "+ largest_name + " : $"+largest );
                    sw.WriteLine("The Customer Spending the least is " + smallest_name + " : $" + smallest);
                    sw.WriteLine("The Number of member with < 12 Month : "+less );
                    sw.WriteLine("The Number of member with >= 12 Month : "+high);
                    sw.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }

        public struct Student_data
        {
            public string Stu_Name;
            public int month;
            public char s_offer;
        }

        static void Main(string[] args)
        {
            Program p = new Program();           
             
            Console.Write("Student Name:  ");
            Console.ReadLine();
            bk:
            Console.Write("Student ID: " );
           
            string abcd = Console.ReadLine();


            int b = 0;
           
            string aa = "";
            for (int i = 0; i < abcd.Length; i++)
            {
                if (char.IsDigit(abcd[i]))
                {
                    aa += abcd[i];
                }
                else
                {
                    //b += abcd[i];
                }
               // intArray[i] = Convert.ToInt32(Convert.ToChar(data.ToCharArray(i)));
            }
            int len = Convert.ToInt32(aa.Length);
            int k = 1;
            int largeno = 0;
            int d = Convert.ToInt32(aa);
            while (len!=k)
            {
               
                int r = d % 10;
                largeno = Math.Max(r, largeno);
                d = d / 10;
                k++;
            }

            int largest = largeno;
            

            if (largest <= 4)
            {
                Console.Write("M: "+ largest);
               // int m = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                Console.WriteLine("Please input " + 4 + " customers information :\n");
                p.gettable(largest);
               p.abc(largest);
                
            }
            else
            {
                Console.WriteLine("Student Id Invalid. Please Re-enter !");
                goto bk;
            }
            Console.ReadLine();

        }
    }
}

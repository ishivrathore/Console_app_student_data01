﻿namespace dt
{
    internal class table
    {
    }
}